package aforo255.com;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstDevopsJobApplicationTests {

	@Test
	void contextLoads() {
	}

}
